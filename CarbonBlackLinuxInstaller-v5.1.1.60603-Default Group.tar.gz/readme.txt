CarbonBlackClientSetup.rpm Standalone Installer archive for group 'Default Group'
  Sensor will connect to: https://awchxcarblk01.awacgbl.com:443

Extract the contents of this archive before running the installer!
