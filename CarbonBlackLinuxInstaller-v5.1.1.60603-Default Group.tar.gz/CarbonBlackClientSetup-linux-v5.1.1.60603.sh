#
# Bootstraps the installation process after the user downloads the zip install package
#    Assumes running as su
#
#	1) Copies the sensor config file to the right location
#	2) Runs the RPM
#
#!/bin/bash

RPM_NAME=CarbonBlackClientSetup-linux-v5.1.1.60603.rpm
SETTINGS_DST_PATH=/var/lib/cb
OLDLOGSDIR=/var/log/cb/sensor
PATH=$PATH:/sbin:/usr/sbin:/bin:/usr/bin
RUNNING_KERNEL=`uname -r`
KERNELBASE=`echo $RUNNING_KERNEL |awk '{split($0,a,"-"); print a[1]}'`
PLATFORM_RPM_DIR=/opt/cbsensor
PLATFORM_RPM=
if [ "$KERNELBASE" == "2.6.32" ]; then
    PLATFORM_RPM=$PLATFORM_RPM_DIR/setup-redhat6.rpm
elif [ "$KERNELBASE" == "3.10.0" ]; then
    PLATFORM_RPM=$PLATFORM_RPM_DIR/setup-redhat7.rpm
fi

# Exit on error

set -e

#
# Figure out where we were run from
#
SCRIPT=$(readlink -f "$0")
INSTALLDIR=$(dirname "$SCRIPT")
echo "Installing cbsensor from $INSTALLDIR"

#
# Setup paths for files 
#
RPM_PATH=$INSTALLDIR/$RPM_NAME
SETTINGS_SRC_PATH=$INSTALLDIR/sensorsettings.ini

#
# Make sure the necessary files are present
#
if [[ ! -f $RPM_PATH ]]; then
	echo "Error: RPM is not present"
	exit -2
fi

if [[ ! -f $SETTINGS_SRC_PATH ]]; then
	echo "Error: config file is not present"
	exit -2
fi

#
# Delete the old logs directory
#
if [[ -d $OLDLOGSDIR ]]; then
        rm -rf $OLDLOGSDIR
fi

#
# Copy the settings file (don't over write it)
#
if [[ ! -d $SETTINGS_DST_PATH ]]; then
        mkdir -p $SETTINGS_DST_PATH
fi

cp -f $SETTINGS_SRC_PATH $SETTINGS_DST_PATH
chmod 644 $SETTINGS_DST_PATH/sensorsettings.ini

#
# Install the RPM
#
/bin/rpm -i $RPM_PATH
if [ $? -ne 0 ]; then
    echo "install failed on outer RPM"
    exit 1
fi

if (test -f /usr/bin/yum); then
    /usr/bin/yum install -y $PLATFORM_RPM
else
    /bin/rpm -i $PLATFORM_RPM
fi

CB_RPM_UNIST=`rpm -qa |grep cb-linux-sensor`
if [[ ! -z $CB_RPM_UNIST ]]; then
    /bin/rpm -e $CB_RPM_UNIST >/dev/null 2>/dev/null
fi
rm -f $PLATFORM_RPM_DIR/*.rpm >/dev/null 2>/dev/null
